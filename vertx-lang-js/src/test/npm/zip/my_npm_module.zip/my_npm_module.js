console.log("Requiring a npm stored in node_modules");
var hello = require = require("my-lib");
var hello_vertx = hello("vertx");
module.exports = hello_vertx;
